# Minecraft Bedrock Cube Craft Scoreboard
[CubeCraft](https://www.cubecraft.net/tags/bedrock-edition/) Server Scoreboard <b>Texture Pack</b>
  > - <b>Picture</b><br><br>
  ![](image/image.png)<br><br>
  > - <b>Title</b><br>
  Set scoreboard as `"cubecraft.sb.logo"` in head-title to shown the image. (scoreboard logo can be changed in files)<br>
  ![image](https://user-images.githubusercontent.com/65983857/119169122-da435b80-ba8b-11eb-8393-d6948bdd5dc1.png)


